<?php

include "vendor/autoload.php";

use GuzzleHttp\Client;

if(isset($_POST['url'])){
    try{
        $client = new Client(['timeout'  => 2.0,'allow_redirects' => false,'http_errors' => true]);
        $response = $client->get($_POST['url']);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            "status" => $response->getStatusCode(),
            "body" => $response->getBody()
        ]);
    }catch (Exception $e){
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            "status" => $e->getCode(),
            "body" => ""
        ]);
    }
}

//$url = "http://test.theideamonitoring.com/get/500";
//$client = new Client(['timeout'  => 2.0,'allow_redirects' => false,'http_errors' => true]);
//try {
//    $response = $client->get($url);
//    var_dump($response->getStatusCode());
//}catch (Exception $e){
//    var_dump($e->getCode());
//}



